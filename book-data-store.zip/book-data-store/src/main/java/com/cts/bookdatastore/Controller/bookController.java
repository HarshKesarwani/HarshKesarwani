package com.cts.bookdatastore.Controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bookdatastore.model.Book;

@RestController
@RequestMapping("api/goodbook/")
public class bookController {
	
	@GetMapping("books")
	public List<Book> getallbooks()
	{
		return Arrays.asList(
				new Book(1,"Math Book","bhasker",99.9,"goob books us")
				);
	}

}
