package com.cts.bookread.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.bookread.model.Book;
import com.cts.bookread.model.Books;

@RestController
@RequestMapping("book")
public class BookController {

	@Autowired
	RestTemplate restTemplate;
	@GetMapping("/{bookId}")
	public Book getBook(@PathVariable("bookId") int id)
	{
		ArrayList book1= restTemplate.getForObject("http://192.168.21.228:8990/api/goodbook/books", ArrayList.class);
		System.out.println(book1);
		
		
		
		return new Book(123,"My Book","Arun",4.5,null);
		
	}
}
