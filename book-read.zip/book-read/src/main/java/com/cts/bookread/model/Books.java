package com.cts.bookread.model;

import java.util.List;

public class Books {

	List<Books> books;

	public List<Books> getBooks() {
		return books;
	}

	public void setBooks(List<Books> books) {
		this.books = books;
	}

	@Override
	public String toString() {
		return "Books [books=" + books + "]";
	}

	
}
